import React from 'react';

const Checkout = () => {
    return (
        <div>
            <h2>Complete your enrollment</h2>
        </div>
    );
};

export default Checkout;