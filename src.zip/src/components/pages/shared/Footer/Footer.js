import React from 'react';

const Footer = () => {
    return (
        <div>
            <p><small>copyright @ 2022. All rights researve</small></p>
        </div>
    );
};

export default Footer;